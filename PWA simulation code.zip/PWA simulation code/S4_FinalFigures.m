clear,clc
close all
%绘制论文中的图形
load S1_TerminalSet_terminal_set_4W
load S2_OnlineTrajectory_Robust_ResultALL
load S2_OnlineTrajectory_ResultALL
load S3_AccumulatedCost

figure(1) %状态空间子区划分
Omega1 = [0 0; 2 -2; 2 2; 0 2; 0 0];
Omega2 = [0 0; 0 2; -2 0; 0 0];
Omega3 = [0 0; -2 0; -2 -2; 2 -2; 0 0];
Omega4 = [-2 0; 0 2; -2 2; -2 0];
polyhedronplot(Omega1, 'r', 0.7)
polyhedronplot(Omega2, 'm', 0.7)
polyhedronplot(Omega3, 'b', 0.7)
polyhedronplot(Omega4, 'k', 0.7)
grid on
box on
xlabel('$x^{(1)}$','interpreter','latex','fontsize',14)
ylabel('$x^{(2)}$','interpreter','latex','fontsize',14)
text(0.9,1,'$\Omega_1$','interpreter','latex','fontsize',18,'color','w')
text(-0.8,0.7,'$\Omega_2$','interpreter','latex','fontsize',18,'color','w')
text(-0.9,-1,'$\Omega_3$','interpreter','latex','fontsize',18,'color','w')
text(-1.5,1.5,'$\Omega_4$','interpreter','latex','fontsize',18,'color','w')
set(gcf, 'PaperSize', [14.815 11.111]);
saveas(gcf,'FourRegions.fig')
saveas(gcf,'FourRegions.pdf')


figure(2) %选择几个不同初始值对应的二维平面轨迹图
polyhedronplot(X01,'k',0.5)
hold on
grid on
box on
polyhedronplot(X02,'k',0.5)
% polyhedronplot(X03,'k',0.5)
h1 = fill([-1.6223 -1.6250 -1.4711 -1.2543 -1.1853 -1.0284 -0.8951 -0.4150 0.6713 0.8449 0.8369 0 -1.6223],...
    [0 0 -1.2310 -1.3231 -1.3212 -1.3038 -1.2796 -1.1680 -0.8910 -0.8449 -0.8369 0 0],'k','FaceAlpha',0.5);
% polyhedronplot(X0,'k',0.5)
KKK = [1 5 7 13 15];
for ks = 1:length(KKK)
    k = KKK(ks);
    % k = ks;
    Xtraj = Xtrajcell{k};
    XtrajRobust = XtrajRobustcell{k};
    plot(Xtraj(1,:),Xtraj(2,:),'r-', 'linewidth',1.2)
    plot(XtrajRobust(1,:),XtrajRobust(2,:),'k--', 'linewidth',1.2)
end
h2 = plot(Xtraj(1,:),Xtraj(2,:),'r-', 'linewidth',1.2);
h3 = plot(XtrajRobust(1,:),XtrajRobust(2,:),'k--', 'linewidth',1.2);
xlabel('$x^{(1)}$','interpreter','latex','fontsize',14)
ylabel('$x^{(2)}$','interpreter','latex','fontsize',14)   
lgd = legend([h1, h2, h3],'$\mathcal{X}_T$','Algorithm 2', 'Robust Method','interpreter','latex','fontsize',12);
lgd.Position = [0.715, 0.155, 0.08, 0.08];
axis([-2, 2, -2, 2])
text(-1.5, 1.3,'$[-1.2\ 1.1]^T$','interpreter','latex','fontsize',12,'color','k')
text(-0.2, 1.8,'$[0\ 1.6]^T$','interpreter','latex','fontsize',12,'color','k')
text(1.2, -1, '$[1.8\ -0.7]^T$','interpreter','latex','fontsize',12,'color','k')
text(-1.2, -1.45, '$[-1\ -1.2]^T$','interpreter','latex','fontsize',12,'color','k')
text(-1.9, -0.95, '$[-1.8\ -0.8]^T$','interpreter','latex','fontsize',12,'color','k')
set(gcf, 'PaperSize', [14.815 11.111]);
saveas(gcf,'MultiTrajectories.fig')
saveas(gcf,'MultiTrajectories.pdf')


figure(3) %不同初始状态的时间曲线及累积成本曲线
% KKK = [1 13];
%%
subplot(2,1,1)
Xtraj = Xtrajcell{1};
XtrajRobust = XtrajRobustcell{1};
h1 = plot(0:100, Xtraj(1,:),'r-', 'linewidth',1)
hold on
grid on
box on
plot(0:100, Xtraj(2,:),'r-', 'linewidth',1)
h2 = plot(0:100, XtrajRobust(1,:),'k--', 'linewidth',1)
plot(0:100, XtrajRobust(2,:),'k--', 'linewidth',1)
xlabel('(a)','interpreter','latex','fontsize',12)
% ylabel('$x^{(1)} / x^{(2)}$','interpreter','latex','fontsize',12)

lgd = legend([h1, h2], 'Algorithm 2', 'Robust Method','interpreter','latex','fontsize',8);
lgd.Position = [0.705, 0.615, 0.08, 0.08];

%
xZoom = [5, 20]; % x 轴的局部区域
yZoom = [-0.1, 0.7]; % y 轴的局部区域
axes('Position', [0.27, 0.77, 0.55, 0.15]); % [left, bottom, width, height]
% 在局部放大图中绘制数据
plot(0:100, Xtraj(1,:),'r-', 'linewidth',1)
hold on
grid on
box on
plot(0:100, Xtraj(2,:),'r-', 'linewidth',1)
plot(0:100, XtrajRobust(1,:),'k--', 'linewidth',1)
plot(0:100, XtrajRobust(2,:),'k--', 'linewidth',1)
xlim(xZoom); % 设置 x 轴的范围
ylim(yZoom);
text(13, 0.5,'$x(0) = [-1.2\ 1.1]^T$','interpreter','latex','fontsize', 12,'color','r')
%
subplot(2,1,2)
plot(Xsum1(1,:),'r-', 'linewidth',1)
hold on
grid on
box on
plot(Xsum2(1,:),'k--', 'linewidth',1)
xlabel('(b)','interpreter','latex','fontsize',12)
ylabel('$\sum_{\tau=0}^{k}{\|x(\tau)\|^2}$','interpreter','latex','fontsize',12)
xZoom = [10, 100]; % x 轴的局部区域
yZoom = [11.4, 11.6]; % y 轴的局部区域
axes('Position', [0.25, 0.17, 0.6, 0.23]); % [left, bottom, width, height]
% 在局部放大图中绘制数据
plot(Xsum1(1,:),'r-', 'linewidth',1)
hold on
grid on
box on
plot(Xsum2(1,:),'k--', 'linewidth',1)
xlim(xZoom); % 设置 x 轴的范围
ylim(yZoom);
% text(40, 11.45,'$x(0) = [-1.2\ 1.1]^T$','interpreter','latex','fontsize',12,'color','r')
set(gcf, 'PaperSize', [14.815 11.111]);
saveas(gcf,'Trajectoryone.fig')
saveas(gcf,'Trajectoryone.pdf')
%%

figure(4)
%%
subplot(2,1,1)
Xtraj = Xtrajcell{13};
XtrajRobust = XtrajRobustcell{13};
h1 = plot(0:100, Xtraj(1,:),'r-', 'linewidth',1)
hold on
grid on
box on
plot(0:100, Xtraj(2,:),'r-', 'linewidth',1)
h2 = plot(0:100, XtrajRobust(1,:),'k--', 'linewidth',1)
plot(0:100, XtrajRobust(2,:),'k--', 'linewidth',1)
xlabel('(a)','interpreter','latex','fontsize',12)
% ylabel('$x^{(2)}$','interpreter','latex','fontsize',12)

lgd = legend([h1, h2], 'Algorithm 2', 'Robust Method','interpreter','latex','fontsize',8);
lgd.Position = [0.765, 0.86, 0.05, 0.05];

%
xZoom = [5, 20]; % x 轴的局部区域
yZoom = [-0.7, 0.7]; % y 轴的局部区域
axes('Position', [0.34, 0.635, 0.55, 0.19]); % [left, bottom, width, height]
% 在局部放大图中绘制数据
plot(0:100, Xtraj(1,:),'r-', 'linewidth',1)
hold on
grid on
box on
plot(0:100, Xtraj(2,:),'r-', 'linewidth',1)
plot(0:100, XtrajRobust(1,:),'k--', 'linewidth',1)
plot(0:100, XtrajRobust(2,:),'k--', 'linewidth',1)
xlim(xZoom); % 设置 x 轴的范围
ylim(yZoom);
text(12, 0.5,'$x(0) = [-1\ -1.2]^T$','interpreter','latex','fontsize', 12,'color','r')
%%
subplot(2,1,2)
plot(Xsum1(13,:),'r-', 'linewidth',1)
hold on
grid on
box on
plot(Xsum2(13,:),'k--', 'linewidth',1)
xlabel('(b)','interpreter','latex','fontsize',12)
ylabel('$\sum_{\tau=0}^{k}{\|x(\tau)\|^2}$','interpreter','latex','fontsize',12)
% text(20, 5,'$x(0) = [-1\ -1.2]^T$','interpreter','latex','fontsize', 8,'color','r')
set(gcf, 'PaperSize', [14.815 11.111]);
saveas(gcf,'Trajectorytwo.fig')
saveas(gcf,'Trajectorytwo.pdf')
% 
% 
figure(5)
h1 = plot(Xsum1(:,end),'r-', 'linewidth', 1)
hold on
grid on
box on
h2 = plot(Xsum2(:,end),'k--', 'linewidth', 1)
ylabel('$\sum_{\tau=0}^{100}{\|x(\tau)\|^2}$','interpreter','latex','fontsize',14)
lgd = legend([h1, h2], 'Algorithm 2', 'Robust Method','interpreter','latex','fontsize', 12);
lgd.Position = [0.72, 0.82, 0.05, 0.05];
set(gcf, 'PaperSize', [14.815 11.111]);
saveas(gcf,'TotalCost.fig')
saveas(gcf,'TotalCost.pdf')

% load TotalCostMultiDelta
% figure(6) %不同Delta值对应的累积成本，结果不理想，无法明显看出什么样的Delta取值更好
% for k = 1:15
%     plot(TotalCostMultiDelta(k,:),'r-*')
%     hold on
%     grid on
%     box on
%     pause
%     clf
% end