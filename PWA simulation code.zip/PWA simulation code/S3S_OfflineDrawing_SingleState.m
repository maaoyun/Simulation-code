clear,clc
close all
%S3_OfflineDrawing
load S1_TerminalSet_terminal_set_4W
% figure(1)
% for k = 1:length(PPn1)
%     polyhedronplot(PPn1{k},'g',1)
%     hold on
% end
% for k = 1:length(PPn2)
%     polyhedronplot(PPn2{k},'g',1)
% end
% for k = 1:length(PPn3)
%     polyhedronplot(PPn3{k},'g',1)
% end
% grid on
% box on
% polyhedronplot(X01,'r',1)
% polyhedronplot(X02,'r',1)
% polyhedronplot(X03,'r',1)
% polyhedronplot(X0,'k',0.5)

%%

x0 =[-1.2; 1.1];
save initialx0 x0
% S2S_OnlineTrajectory_Robust
% 
% S2S_OnlineTrajectory

load S2_OnlineTrajectory_Robust_Result
load S2_OnlineTrajectory_Result


close all
% 单个初始状态运行结果对比
figure(1)
polyhedronplot(X01,'r',1)
hold on
grid on
box on
polyhedronplot(X02,'r',1)
polyhedronplot(X03,'r',1)
polyhedronplot(X0,'k',0.5)
plot(Xtraj(1,:),Xtraj(2,:),'r-*')
plot(XtrajRobust(1,:),XtrajRobust(2,:),'k-o')

figure(2)
plot(Xtraj(1,:),'r-*')
hold on
grid on
box on
plot(Xtraj(2,:),'r-*')
plot(XtrajRobust(1,:),'k-o')
plot(XtrajRobust(2,:),'k-o')

figure(3)
stairs(Utraj,'r')
grid on
hold on
box on
stairs(UtrajRobust,'k')

Xsum1 = zeros(1,100); Xsum2 = zeros(1,100);
Xsum1(1) = Xtraj(:,1)'*Xtraj(:,1);
Xsum2(1) = XtrajRobust(:,1)'*XtrajRobust(:,1);
for k = 2:100
    Xsum1(k) = Xsum1(k-1) + Xtraj(:,k)'*Xtraj(:,k);
    Xsum2(k) = Xsum2(k-1) + XtrajRobust(:,k)'*XtrajRobust(:,k);
end
figure(4)
plot(Xsum1,'r-*')
hold on
grid on
box on
plot(Xsum2,'k-o')

figure(5)
plot(ValueEta,'r-*')
hold on
grid on
box on
plot(ValueEtaRobust,'k-o')


% UtrajRobustcell{7} = UtrajRobust; ValueEtaRobustcell{7} = ValueEtaRobust; XtrajRobustcell{7} = XtrajRobust;
% save S2_OnlineTrajectory_Robust_ResultALL UtrajRobustcell ValueEtaRobustcell XtrajRobustcell

% RegionAllcell{7} = RegionAll; Utrajcell{7} =  Utraj; ValueEtacell{7} = ValueEta;
% Valuealphacell{7} = Valuealpha; Valuedeltaucell{7} = Valuedeltau; Valuedeltaxcell{7} = Valuedeltax; Xtrajcell{7} = Xtraj;
% save S2_OnlineTrajectory_ResultALL RegionAllcell Utrajcell ValueEtacell Valuealphacell Valuedeltaucell Valuedeltaxcell Xtrajcell