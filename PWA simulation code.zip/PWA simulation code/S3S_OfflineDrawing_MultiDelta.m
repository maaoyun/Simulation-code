clear,clc
close all
%%
%生成2个不同初始值对应15个不同Delta的累积成本
TotalCostMultiDelta = zeros(15,15);
save TotalCostMultiDelta TotalCostMultiDelta
Xinit = [-1.2 1.1; -1.5 0.3; -1.6 -1; -0.1 1.5; 0 1.6;...
    1 1; 1.8 -0.7; 1 -0.8; 0.5 -0.9; 0 -1;...
    0 -1; -0.5 -1.1; -1 -1.2; -1.5 -1; -1.8 -0.8]';
save Xinit Xinit
DELTA = linspace(0,1.4,15);
save DELTA DELTA
% for stepm = 1:15
%     save stepmat stepm
%     load Xinit
%     x0 = Xinit(:,stepm);
%     save initialx0 x0
%     for ddelta = 1:15
%         load DELTA
%         Delta = DELTA(ddelta);
%         save Deltamat  Delta ddelta
%         S2S_OnlineTrajectoryMultiDelta
%         load stepmat
%         load Deltamat
%         load TotalCostMultiDelta
%         TotalCostMultiDelta(stepm,ddelta) = totalcost;
%         save TotalCostMultiDelta TotalCostMultiDelta
%     end
% end