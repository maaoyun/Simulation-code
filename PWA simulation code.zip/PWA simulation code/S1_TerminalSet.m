clear,clc
close all
warning off
%S1_TerminalSet
A11 = [1 0.8; 0 1.05]; B11 = [1; 0.3];
A12 = [1 0.9; 0 1.05]; B12 = [1.2; 0.3];
A21 = [1 0.8; 0 1.15]; B21 = [1; 0.3];
A22 = [1 0.9; 0 1.15]; B22 = [1.2; 0.3];
A31 = [1 0.8; 0 1.05]; B31 = [1; 0.3];
A32 = [1 0.8; 0 1.15]; B32 = [1.2; 0.3];
A41 = [1 0.9; 0 1.05]; B41 = [1; 0.3];
A42 = [1 0.9; 0 1.15]; B42 = [1.2; 0.3];
C1 = [0; 0]; C2 = C1; C3 = C1; C4 = [-0.1; 0.1];

%%
Q = [1 0; 0 1]; R = 1;
roots = [0.7 0.7];
K1 = calculate_K((A11+A12)/2,(B11+B12)/2,[0.7 0.7]);
K2 = calculate_K((A21+A22)/2,(B21+B22)/2,[0.85 0.8]);
K3 = calculate_K((A31+A32)/2,(B31+B32)/2,[0.8 0.6]);
Phi11 = A11 + B11*K1;
Phi12 = A12 + B12*K1;
Phi21 = A21 + B21*K2;
Phi22 = A22 + B22*K2;
Phi31 = A31 + B31*K3;
Phi32 = A32 + B32*K3;
Omega1 = [0 0; 2 -2; 2 2; 0 2; 0 0];
Omega2 = [0 0; 0 2; -2 0; 0 0];
Omega3 = [0 0; -2 0; -2 -2; 2 -2; 0 0];
Omega4 = [-2 0; 0 2; -2 2; -2 0];
%%
Worig = 0.01*[1 1; -1 1; -1 -1; 1 -1; 1 1];
W = 4*Worig;
%%
Umax = 1;
Y1 = feedback_region(K1,Umax,2,'r');
Y2 = feedback_region(K2,Umax,2,'b');
Y3 = feedback_region(K3,Umax,2,'k');
axis([-2,2,-2,2])

%%
temp1 = {};
temp1{1} = Omega1; temp1{2} = Y1;
[Y01x, Y01y] = Multipolyints(temp1);
Y01 = [Y01x Y01y];
%
temp2 = {};
temp2{1} = Omega2; temp2{2} = Y2;
[Y02x, Y02y] = Multipolyints(temp2);
Y02 = [Y02x Y02y];
%
temp3 = {};
temp3{1} = Omega3; temp3{2} = Y3;
[Y03x, Y03y] = Multipolyints(temp3);
Y03 = [Y03x Y03y];

%%
figure
polyhedronplot(Y01,'r',0.75)
hold on
grid on
box on
axis([-2,2,-2,2])
polyhedronplot(Y02,'b',0.95)
polyhedronplot(Y03,'k',0.95)
XU = {};
XU{1} = Y01; XU{2} = Y02; XU{3} = Y03;
%%
A{1} = A11; A{2} = A12; A{3} = A21; A{4} = A22; A{5} = A31; A{6} = A32; A{7} = A41; A{8} = A42;
B{1} = B11; B{2} = B12; B{3} = B21; B{4} = B22; B{5} = B31; B{6} = B32; B{7} = B41; B{8} = B42;
C{1} = C1; C{2} = C2; C{3} = C3; C{4} = C4;
K{1} = K1; K{2} =K2; K{3} = K3;
Phi{1} = Phi11; Phi{2} = Phi12; Phi{3} = Phi21; Phi{4} = Phi22; Phi{5} = Phi31; Phi{6} = Phi32;
Omega{1} = Omega1; Omega{2} = Omega2; Omega{3} = Omega3; Omega{4} = Omega4;
%%
temp = {};
temp{1} = Y1; temp{2} = Y2; temp{3} = Y3; temp{4} = [-2 0; 0 2; 2 2; 2 -2; -2 -2; -2 0];
[X0x,X0y] = Multipolyints(temp);
X0 = [X0x, X0y];
polyhedronplot(X0,'y',0.5)
YAb = {};
for k = 1:3
    [YAb{k,1},YAb{k,2}] = vert2con(XU{k});
end
%%
%%这里是为了计算最小鲁棒正不变集，完成之后保存直接调用即可。
% for k = 1:20
%     X0 = convex_expand(X0,YAb,XU);
%     polyhedronplot(X0,'y',0.5)
% end
% save DMPC_PWA_1_state_feedback_region X0
% load S1_TerminalSet_state_feedback_region
% %%
% NN = 50;
% for k = 1:NN
%     k
%     figure
%     polyhedronplot(X0,'r',1)
%     X00 = minkdiff(X0,W);
%     X011 = (Phi11^-1*X00')';
%     X012 = (Phi12^-1*X00')';
%     X021 = (Phi21^-1*X00')';
%     X022 = (Phi22^-1*X00')';
%     X031 = (Phi31^-1*X00')';
%     X032 = (Phi32^-1*X00')';
%     temp = {};
%     temp{1} = X011; temp{2} = X012; temp{3} = X021; temp{4} = X022; temp{5} = X031; temp{6} = X032; temp{7} = X0;
%     [X0x,X0y] = Multipolyints(temp)
%     X0 = [X0x, X0y];
%     % polyhedronplot(X011,'k',0.5)
%     % polyhedronplot(X012,'k',0.5)
%     % polyhedronplot(X021,'k',0.5)
%     % polyhedronplot(X022,'k',0.5)
%     % polyhedronplot(X031,'k',0.5)
%     % polyhedronplot(X032,'k',0.5)
%     polyhedronplot(X0,'y',0.5)
%     grid on
%     box on
%     pause(1)
% end
% save S1_TerminalSet_minimal_invariant_set_4W X0

load S1_TerminalSet_minimal_invariant_set_4W %调用前期计算完成的最小鲁棒正不变集
% figure
% polyhedronplot(X0,'r')
% X0_original = X0;
% X0 = minkdiff(X0,W);
% polyhedronplot(X0,'y')
% %%
% PP = {};
% %
% temp{1} = (Phi11^-1*X0')', temp{2} = (Phi12^-1*X0')', temp{3} = Y01;
% [Tex,Tey] = Multipolyints(temp);
% PP{1,1} = [Tex, Tey];
% %
% temp{1} = (Phi21^-1*X0')', temp{2} = (Phi22^-1*X0')', temp{3} = Y02;
% [Tex,Tey] = Multipolyints(temp);
% PP{1,2} = [Tex, Tey];
% %
% temp{1} = (Phi31^-1*X0')', temp{2} = (Phi32^-1*X0')', temp{3} = Y03;
% [Tex,Tey] = Multipolyints(temp);
% PP{1,3} = [Tex, Tey];
% 
% %
% figure
% polyhedronplot(PP{1,1},'r')
% polyhedronplot(PP{1,2},'b')
% polyhedronplot(PP{1,3},'k')
% % %%
% Steps = 10;
% for step = 2:Steps
%     step
%     for i = 1:3
%         for j = 1:3^(step-1)
%             temps = {};
%             flagempty = isempty(PP{step-1,j});
%             if flagempty == 0
%                 try
%                     minktemp = minkdiff(PP{step-1,j},W);
%                 catch
%                     PP{step, (i-1)*3^(step-1) + j} = [];
%                     continue;
%                 end
%                 flag = 0;
%                 temps{1} = XU{i}; 
% 
%                 ttss = {};
%                 ttss{1} = (Phi{2*i-1}^-1*minktemp')'; ttss{2} = (Phi{2*i}^-1*minktemp')';
%                 flagttss = 0;
%                 flagttss = check_intersect(ttss{1},ttss{2});
%                 if flagttss == 0
%                     flag = 0;
%                 else
%                     [ttssx, ttssy] = Multipolyints(ttss);
%                     ttssxy = [ttssx, ttssy];
%                     temps{2} = ttssxy;
%                     flag = check_intersect(temps{1},temps{2});
%                 end
%                 if flag == 0
%                     PP{step,(i-1)*3^(step-1)+j} = [];
%                 else
%                     [tempx, tempy] = Multipolyints(temps);
%                     if [tempx, tempy] <= 1e-3 & [tempx, tempy] >= -1e-3
%                         PP{step,(i-1)*3^(step-1)+j} = [];
%                     else
%                         PPtemp = [tempx, tempy];
%                         PP{step, (i-1)*3^(step-1) + j} = PPtemp;
%                     end
%                 end
%             else
%                 PP{step, (i-1)*3^(step-1) + j} = [];
%             end
%             %%
%             flagempty = isempty(PP{step, (i-1)*3^(step-1) + j});
%         if flagempty == 0
%             polyhedronplot(PP{step, (i-1)*3^(step-1) + j},'r',0.5)
%         else
%             continue;
%         end
%         %%
%         end
%     end
% end
% 
% figure
% polyhedronplot(X0,'y')
% hold on
% grid on
% color = ['r','g','b','k','y'];
% PPnonempty = {};
% ncount = 1;
% for step = 1:10
%     for k = 1:3^step
%         flagempty = isempty(PP{step,k});
%         if flagempty == 0
%             polyhedronplot(PP{step,k},'k',0.75)
%             PPnonempty{ncount} = PP{step,k};
%             ncount = ncount + 1;
%         else
%             continue;
%         end
%     end
% end
% polyhedronplot(X0,'y')
% PPAb = {};
% for k = 1:ncount-1
%     [PPAb{k,1}, PPAb{k,2}] = vert2con(PPnonempty{k});
% end
% save S1_TerminalSet_PPAb PPAb PPnonempty ncount
load S1_TerminalSet_PPAb 
%%
%PPAb PPnonempty在三个子区内的情况，按区域划分。
% PPn1 = {}; PPn2 = {}; PPn3 = {};
% Pn1 = 1; Pn2 = 1; Pn3 = 1;
% for k = 1:ncount-1
%     if PPnonempty{k}(:,1) <= 0 & PPnonempty{k}(:,2) >= 0
%         PPn2{Pn2} = PPnonempty{k};
%         Pn2 = Pn2 + 1;
%     elseif PPnonempty{k}(:,1) + PPnonempty{k}(:,2) >= 0
%         PPn1{Pn1} = PPnonempty{k};
%         Pn1 = Pn1 + 1;
%     else 
%         PPn3{Pn3} = PPnonempty{k};
%         Pn3 = Pn3 + 1;
%     end
% end
% 
% for k = 1:Pn1-1
%     [PAb1{k,1}, PAb1{k,2}] = vert2con(PPn1{k});
% end
% for k = 1:Pn2-1
%     [PAb2{k,1}, PAb2{k,2}] = vert2con(PPn2{k});
% end
% for k = 1:Pn3-1
%     [PAb3{k,1}, PAb3{k,2}] = vert2con(PPn3{k});
% end
% %
% %%
% save S1_TerminalSet_P_collection_4W PAb1 PAb2 PAb3 PPn1 PPn2 PPn3

load S1_TerminalSet_P_collection_4W
figure
for k = 1:length(PPn1)
    polyhedronplot(PPn1{k},'k',0.5)
    hold on
end
for k = 1:length(PPn2)
    polyhedronplot(PPn2{k},'k',0.5)
end
for k = 1:length(PPn3)
    polyhedronplot(PPn3{k},'k',0.5)
end
polyhedronplot(X0,'r',0.5)
% %%
% %求最小鲁棒正不变集在各个子区内的集合
temp1 = {};
temp1{1} = Omega1; temp1{2} = X0;
[X01x, X01y] = Multipolyints(temp1);
X01 = [X01x X01y];
%
temp2 = {};
temp2{1} = Omega2; temp2{2} = X0;
[X02x, X02y] = Multipolyints(temp2);
X02 = [X02x X02y];
%
temp3 = {};
temp3{1} = Omega3; temp3{2} = X0;
[X03x, X03y] = Multipolyints(temp3);
X03 = [X03x X03y];

%%

for k = 1:10
    if k <= 3
        flag = 0;
    else
        flag = 1;
    end
    X01 = convex_expand(X01,PAb1,PPn1,flag);
    X02 = convex_expand(X02,PAb2,PPn2,flag);
    X03 = convex_expand(X03,PAb3,PPn3,flag);
end
for k = 1:20
    k
    pause(1)
    X01(find(X01<=1e-2 & X01>=-1e-2)) = 0;
    X02(find(X02<=1e-2 & X02>=-1e-2)) = 0;
    X03(find(X03<=1e-2 & X03>=-1e-2)) = 0;
    X01 = convex_expand(X01,PAb1,PPn1);
    X02 = convex_expand(X02,PAb2,PPn2);
    X03 = convex_expand(X03,PAb3,PPn3);
end

%%
%算法在边缘处可能会无法完全扩展，需要手动补充顶点。
xx01 = [2 0.193548; 2 -0.519];
X01 = [X01; xx01; 0.921622 -0.921622];
s01 = convhull(X01);
X01 = X01(s01,:);
X02 = [X02; -0.820187 0.549914; -1.36611 0.367183; -1.78283 0.217169; -2 0];
s02 = convhull(X02);
X02 = X02(s02,:);
X03 = [X03; -1.625 0; -1.47112 -1.23101; 0.844864 -0.844864; 0.671259 -0.890962; -0.414967 -1.16797; -0.829938 -1.26445; -0.895094 -1.2796];
s03 = convhull(X03);
X03 = X03(s03,:);

save S1_TerminalSet_terminal_set_4W A B C K Omega Phi Q R Umax W X0 X01 X02 X03 PPn1 PPn2 PPn3

%%
%计算X_T - W*
% [m1,n1] = size(X01);
% [m2,n2] = size(X02);
% [m3,n3] = size(X03);
% X01inter = []; X02inter = []; X03inter = []; 
% for ks1 = 1:m1
%     for ks2 = 1:4
%         X01inter(4*(ks1-1)+ks2,:) = X01(ks1,:) - W(ks2,:);
%     end
% end
% for ks1 = 1:m2
%     for ks2 = 1:4
%         X02inter(4*(ks1-1)+ks2,:) = X02(ks1,:) - W(ks2,:);
%     end
% end
% for ks1 = 1:m3
%     for ks2 = 1:4
%         X03inter(4*(ks1-1)+ks2,:) = X03(ks1,:) - W(ks2,:);
%     end
% end
% [Ax01,bx01] = vert2con(X01);
% [Ax02,bx02] = vert2con(X02);
% [Ax03,bx03] = vert2con(X03);
% X0inter = [X01inter; X02inter; X03inter];
% [mx0inter, nx0inter] = size(X0inter);
% X0interhold = [];
% for kmx = 1:mx0inter
%     if Ax01*X0inter(kmx,:)' <= bx01
%         X0interhold = [X0interhold; X0inter(kmx,:)];
%         continue
%     elseif Ax02*X0inter(kmx,:)' <= bx02
%         X0interhold = [X0interhold; X0inter(kmx,:)];
%         continue
%     elseif Ax03*X0inter(kmx,:)' <= bx03
%         X0interhold = [X0interhold; X0inter(kmx,:)];
%     end
% end
X01W = minkdiff(X01,W);
X02W = minkdiff(X02,W);
X03W = minkdiff(X03,W);
X01W1 = [0 0; 0.78 -0.78; 0.8 -0.72; 0.04 0.04; 0 0];
X01W2 = [0 0; 0.04 0.04; 0.04 0.725;0 0.725; 0 0];
X02W1 = [0 0; 0 0.725048; -0.04 0.725048; -0.04 0; 0 0];
X02W2 = [-0.04 0; -0.04 0.04; -1.575 0.04; -1.575 0; -0.04 0];
X03W1 = [0 0; -1.575 0; -1.575 -0.04; -0.04 -0.04; 0 0];
X03W2 = [0 0; -0.04 -0.04; 0.74165 -0.82165; 0.78 -0.78; 0 0];
polyhedronplot(X01W1,'g',0.6)
polyhedronplot(X01W2,'g',0.6)
polyhedronplot(X02W1,'g',0.6)
polyhedronplot(X02W2,'g',0.6)
polyhedronplot(X03W1,'g',0.6)
polyhedronplot(X03W2,'g',0.6)
save S1_TerminalSet_terminal_set_4W A B C K Omega Phi Q R Umax W X0 X01 X02 X03 PPn1 PPn2 PPn3 X01W X02W X03W X01W1 X01W2 X02W1 X02W2 X03W1 X03W2