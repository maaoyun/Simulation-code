clear,clc
close all
Omega1 = [0 0; 2 -2; 2 2; 0 2; 0 0];
Omega2 = [0 0; 0 2; -2 0; 0 0];
Omega3 = [0 0; -2 0; -2 -2; 2 -2; 0 0];
Omega4 = [-2 0; 0 2; -2 2; -2 0];
polyhedronplot(Omega1, 'r', 0.7)
polyhedronplot(Omega2, 'm', 0.7)
polyhedronplot(Omega3, 'b', 0.7)
polyhedronplot(Omega4, 'k', 0.7)
grid on
box on
xlabel('$x^{(1)}$','interpreter','latex','fontsize',14)
ylabel('$x^{(2)}$','interpreter','latex','fontsize',14)
saveas(gcf,'FourRegions.fig')
saveas(gcf,'FourRegions.pdf')
text(0.9,1,'$\Omega_1$','interpreter','latex','fontsize',18,'color','w')
text(-0.8,0.7,'$\Omega_2$','interpreter','latex','fontsize',18,'color','w')
text(-0.9,-1,'$\Omega_3$','interpreter','latex','fontsize',18,'color','w')
text(-1.5,1.5,'$\Omega_4$','interpreter','latex','fontsize',18,'color','w')