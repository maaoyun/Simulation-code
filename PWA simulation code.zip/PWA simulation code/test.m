clear,clc
close all
X = [1 1; -1 1; -1 -1; 1 -1; 1 1];
A1 = [1 0.8; 0 1.05];
A2 = [1 0.8; 0 1.2];
A3 = [1 0.9; 0 1.2];
A4 = [1 0.85; 0 1.1];
AX1 = (A1^-1*X')';
AX2 = (A2^-1*X')';
AX3 = (A3^-1*X')';
AX4 = (A4^-1*X')';
polyhedronplot(X,'r',0.5)
hold on
grid on
box on
polyhedronplot(AX1,'g',0.5)
polyhedronplot(AX2,'b',0.5)
polyhedronplot(AX3,'y',0.5)
polyhedronplot(AX4,'k',0.5)