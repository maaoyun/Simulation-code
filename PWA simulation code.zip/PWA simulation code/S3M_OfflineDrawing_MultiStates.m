clear,clc
close all
%S3_OfflineDrawing_MultiStates
% load S1_TerminalSet_terminal_set_4W
% figure(1)
% for k = 1:length(PPn1)
%     polyhedronplot(PPn1{k},'g',1)
%     hold on
% end
% for k = 1:length(PPn2)
%     polyhedronplot(PPn2{k},'g',1)
% end
% for k = 1:length(PPn3)
%     polyhedronplot(PPn3{k},'g',1)
% end
% grid on
% box on
% polyhedronplot(X01,'r',1)
% polyhedronplot(X02,'r',1)
% polyhedronplot(X03,'r',1)
% polyhedronplot(X0,'k',0.5)

%%
%生成15个不同初始值的结果
UtrajRobustcell = cell(15,1); ValueEtaRobustcell = cell(15,1); XtrajRobustcell = cell(15,1);
save S2_OnlineTrajectory_Robust_ResultALL UtrajRobustcell ValueEtaRobustcell XtrajRobustcell
RegionAllcell = cell(15,1); Utrajcell = cell(15,1); ValueEtacell = cell(15,1); Valuealphacell = cell(15,1); 
Valuedeltaucell = cell(15,1); Valuedeltaxcell = cell(15,1); Xtrajcell = cell(15,1);
save S2_OnlineTrajectory_ResultALL RegionAllcell Utrajcell ValueEtacell Valuealphacell Valuedeltaucell Valuedeltaxcell Xtrajcell
Xinit = [-1.2 1.1; -1.5 0.3; -1.6 -1; -0.1 1.5; 0 1.6;...
    1 1; 1.8 -0.7; 1 -0.8; 0.5 -0.9; 0 -1;...
    0 -1; -0.5 -1.1; -1 -1.2; -1.5 -1; -1.8 -0.8]';
save Xinit Xinit
for stepm = 1:15
    % disp(stepm)
    tic
    save stepmat stepm
    load Xinit
    x0 = Xinit(:,stepm);
    save initialx0 x0
    S2M_OnlineTrajectory_Robust
    load stepmat
    load S2_OnlineTrajectory_Robust_ResultALL
    UtrajRobustcell{stepm} = UtrajRobust; ValueEtaRobustcell{stepm} = ValueEtaRobust; XtrajRobustcell{stepm} = XtrajRobust;
    save S2_OnlineTrajectory_Robust_ResultALL UtrajRobustcell ValueEtaRobustcell XtrajRobustcell

    S2M_OnlineTrajectory
    load stepmat
    load S2_OnlineTrajectory_ResultALL
    RegionAllcell{stepm} = RegionAll; Utrajcell{stepm} =  Utraj; ValueEtacell{stepm} = ValueEta;
    Valuealphacell{stepm} = Valuealpha; Valuedeltaucell{stepm} = Valuedeltau; Valuedeltaxcell{stepm} = Valuedeltax; Xtrajcell{stepm} = Xtraj;
    save S2_OnlineTrajectory_ResultALL RegionAllcell Utrajcell ValueEtacell Valuealphacell Valuedeltaucell Valuedeltaxcell Xtrajcell
    toc
end



% % %%
% 
% load S1_TerminalSet_terminal_set_4W
% load S2_OnlineTrajectory_Robust_ResultALL
% load S2_OnlineTrajectory_ResultALL
% 
% 
% 
% figure(1)
% polyhedronplot(X01,'r',1)
% hold on
% grid on
% box on
% polyhedronplot(X02,'r',1)
% polyhedronplot(X03,'r',1)
% polyhedronplot(X0,'k',0.5)
% for k = 1:15
%     Xtraj = Xtrajcell{k};
%     XtrajRobust = XtrajRobustcell{k};
%     plot(Xtraj(1,:),Xtraj(2,:),'r-*')
%     plot(XtrajRobust(1,:),XtrajRobust(2,:),'k-o')
% end
% 
% figure(2)
% for k = 1:15
%     Xtraj = Xtrajcell{k};
%     XtrajRobust = XtrajRobustcell{k};
%     plot(Xtraj(1,:),'r-*')
%     hold on
%     grid on
%     box on
%     plot(Xtraj(2,:),'r-*')
%     plot(XtrajRobust(1,:),'k-o')
%     plot(XtrajRobust(2,:),'k-o')
% end
% 
% % figure(3)
% % stairs(Utraj,'r')
% % grid on
% % hold on
% % box on
% % stairs(UtrajRobust,'k')
% 
% Xsum1 = zeros(15,100); Xsum2 = zeros(15,100);
% for k = 1:15
%     Xtraj = Xtrajcell{k};
%     XtrajRobust = XtrajRobustcell{k};
%     Xsum1(k,1) = Xtraj(:,1)'*Xtraj(:,1);
%     Xsum2(k,1) = XtrajRobust(:,1)'*XtrajRobust(:,1);
%     for kk = 2:100
%         Xsum1(k,kk) = Xsum1(k,kk-1) + Xtraj(:,kk)'*Xtraj(:,kk);
%         Xsum2(k,kk) = Xsum2(k,kk-1) + XtrajRobust(:,kk)'*XtrajRobust(:,kk);
%     end
% end
% save S3_AccumulatedCost Xsum1 Xsum2
% 
% figure(4)
% for k = 1:15
%     plot(Xsum1(k,:),'r-*')
%     hold on
%     grid on
%     box on
%     plot(Xsum2(k,:),'k-o')
% end
% 
% % figure(5)
% % plot(ValueEta,'r-*')
% % hold on
% % grid on
% % box on
% % plot(ValueEtaRobust,'k-o')