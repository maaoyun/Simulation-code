clear%,clc
close all
warning off
% S2_OnlineTrajectory_Robust
%该方法虽然写了数据驱动的历史数据组合，但是历史数据一直为空，所以等价于原始鲁棒方法
load S1_TerminalSet_terminal_set_4W
bar_alpha = 1.5;
P = eye(2);
[AOmega1, bOmega1] = vert2con(Omega{1});
[AOmega2, bOmega2] = vert2con(Omega{2});
[AOmega3, bOmega3] = vert2con(Omega{3});
[AOmega4, bOmega4] = vert2con(Omega{4});
%%
[AX01W,bX01W] = vert2con(X01W);
[AX02W,bX02W] = vert2con(X02W);
[AX03W,bX03W] = vert2con(X03W);
[AX01W1,bX01W1] = vert2con(X01W1);
[AX01W2,bX01W2] = vert2con(X01W2);
[AX02W1,bX02W1] = vert2con(X02W1);
[AX02W2,bX02W2] = vert2con(X02W2);
[AX03W1,bX03W1] = vert2con(X03W1);
[AX03W2,bX03W2] = vert2con(X03W2);
%%
Areal{1} = [1 0.85; 0 1.05]; Breal{1} = [1; 0.3];  % Areal{1} = [1 0.85; 0 1.1]; Breal{1} = [1; 0.3];
Areal{2} = [1 0.85; 0 1.15]; Breal{2} = [1.1; 0.3]; % Areal{2} = [1 0.85; 0 1.2]; Breal{2} = [1.1; 0.3];
Areal{3} = [1 0.8; 0 1.15]; Breal{3} = [1.1; 0.3];
Areal{4} = [1 0.9; 0 1.15]; Breal{4} = [1.2; 0.3];
%%
% x0 = [-1.2; -1.2];
load initialx0
Steps = 100;
Xtraj = zeros(2,Steps+1);
Utraj = zeros(1,Steps+1);
ValueEta = zeros(1,Steps);
Xtraj(:,1) = x0;
% W = 2e-2*(rand(2,Steps) - 0.5); %生成过程中的扰动序列
load WDetermined %读取提前生成的扰动序列，对比时使用同一组扰动
Xhist{1} = zeros(2,2); Uhist{1} = zeros(1,2); Xphist{1} = zeros(2,2); %分区存储历史数据，初始时刻为0
Xhist{2} = zeros(2,2); Uhist{2} = zeros(1,2); Xphist{2} = zeros(2,2);
Xhist{3} = zeros(2,2); Uhist{3} = zeros(1,2); Xphist{3} = zeros(2,2);
Xhist{4} = zeros(2,2); Uhist{4} = zeros(1,2); Xphist{4} = [-0.1 -0.1; 0.1 0.1];
RegionFlag = []; %状态所在子区标记
for k = 1:Steps
    disp(k)
    % tic
    x0 = Xtraj(:,k);
    %判断当前状态所在的子区
    if AOmega1*x0 <= bOmega1
        RegionFlag = 1;
    elseif AOmega2*x0 <= bOmega2
        RegionFlag = 2;
    elseif AOmega3*x0 <= bOmega3
        RegionFlag = 3;
    elseif AOmega4*x0 <= bOmega4
        RegionFlag = 4;
    else
        RegionFlag = []; %此处防止出现判断不在四个子区内的异常情况，出现时程序会终止。...
        % 另外，按照现在的if判断逻辑，对于可能出现在子区边界上的点，会优先认定在小序号子区内，因此不影响程序运行。
    end
    %%
    Atemp1 = A{2*RegionFlag-1}; Atemp2 = A{2*RegionFlag};
    Btemp1 = B{2*RegionFlag-1}; Btemp2 = B{2*RegionFlag};
    Ctemp = [C{RegionFlag} C{RegionFlag}];
    Xhistemp = Xhist{RegionFlag}; Uhistemp = Uhist{RegionFlag}; Xphistemp = Xphist{RegionFlag};
    %%
    %定义优化变量
    yalmip('clear')
    u = sdpvar(1,1); eta = sdpvar(1,1); xp = sdpvar(2,4); 
    dd = binvar(9,4); %A和B各种两个顶点，因此下一时刻的预测状态有四种组合。这四种状态都需要满足在终端集内。
    obj = eta;
    cst = [0 <= eta, eta <= 1];%, -1.5 <= alpha, alpha <= 1.5];
    cst = [cst, -1 <= u, u <= 1];
    cst = [cst, sum(dd(:,1)) == 1, sum(dd(:,2)) == 1, sum(dd(:,3)) == 1, sum(dd(:,4)) == 1];
    %
    cst = [cst, xp(:,1) == Atemp1*x0 + Btemp1*u + C{RegionFlag}];
    cst = [cst, implies(dd(:,1), AX01W*xp(:,1) <= eta*bX01W | AX02W*xp(:,1) <= eta*bX02W | AX03W*xp(:,1) <= eta*bX03W | ...
        AX01W1*xp(:,1) <= eta*bX01W1 | AX01W2*xp(:,1) <= eta*bX01W2 | AX02W1*xp(:,1) <= eta*bX02W1 | AX02W2*xp(:,1) <= eta*bX02W2 | ...
        AX03W1*xp(:,1) <= eta*bX03W1 | AX03W2*xp(:,1) <= eta*bX03W2)];
    cst = [cst, xp(:,2) == Atemp1*x0 + Btemp2*u + C{RegionFlag}];
    cst = [cst, implies(dd(:,2), AX01W*xp(:,2) <= eta*bX01W | AX02W*xp(:,2) <= eta*bX02W | AX03W*xp(:,2) <= eta*bX03W | ...
        AX01W1*xp(:,2) <= eta*bX01W1 | AX01W2*xp(:,2) <= eta*bX01W2 | AX02W1*xp(:,2) <= eta*bX02W1 | AX02W2*xp(:,2) <= eta*bX02W2 | ...
        AX03W1*xp(:,2) <= eta*bX03W1 | AX03W2*xp(:,2) <= eta*bX03W2)];
    cst = [cst, xp(:,3) == Atemp2*x0 + Btemp1*u + C{RegionFlag}];
    cst = [cst, implies(dd(:,3), AX01W*xp(:,3) <= eta*bX01W | AX02W*xp(:,3) <= eta*bX02W | AX03W*xp(:,3) <= eta*bX03W | ...
        AX01W1*xp(:,3) <= eta*bX01W1 | AX01W2*xp(:,3) <= eta*bX01W2 | AX02W1*xp(:,3) <= eta*bX02W1 | AX02W2*xp(:,3) <= eta*bX02W2 | ...
        AX03W1*xp(:,3) <= eta*bX03W1 | AX03W2*xp(:,3) <= eta*bX03W2)];
    cst = [cst, xp(:,4) == Atemp2*x0 + Btemp2*u + C{RegionFlag}];
    cst = [cst, implies(dd(:,4), AX01W*xp(:,4) <= eta*bX01W | AX02W*xp(:,4) <= eta*bX02W | AX03W*xp(:,4) <= eta*bX03W | ...
        AX01W1*xp(:,4) <= eta*bX01W1 | AX01W2*xp(:,4) <= eta*bX01W2 | AX02W1*xp(:,4) <= eta*bX02W1 | AX02W2*xp(:,4) <= eta*bX02W2 | ...
        AX03W1*xp(:,4) <= eta*bX03W1 | AX03W2*xp(:,4) <= eta*bX03W2)];
    ops = sdpsettings('verbose',0);
    sol = optimize(cst,obj,ops);
    if sol.problem ~= 0
        break;
    end
    valueu = value(u);
    x0 = Areal{RegionFlag}*x0 + Breal{RegionFlag}*valueu + C{RegionFlag} + W(:,k);
    Xtraj(:,k+1) = x0;
    Utraj(:,k) = valueu;
    ValueEta(k) = value(eta);
    % toc
end
%%
XtrajRobust = Xtraj; UtrajRobust = Utraj; ValueEtaRobust = ValueEta;
save S2_OnlineTrajectory_Robust_Result XtrajRobust UtrajRobust ValueEtaRobust
%%
figure(1)
polyhedronplot(X01,'g',0.6)
grid on
hold on
box on
polyhedronplot(X02,'g',0.6)
polyhedronplot(X03,'g',0.6)
plot(Xtraj(1,:),Xtraj(2,:),'r-*')
axis([-2,2,-2,2])
%
figure(2)
stairs(Utraj,'r')
grid on
hold on
box on
%
figure(3)
plot(ValueEta,'r-*')
grid on
box on
hold on