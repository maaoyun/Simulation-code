% clear,clc
% close all
plot(0:99,ValueEtacell{1},'r-', 'linewidth', 1.2)
xlabel('Time instant $k$','interpreter','latex','fontsize',14)
ylabel('$\eta(k)$','interpreter','latex','fontsize',14)
grid on
box on
set(gcf, 'PaperSize', [14.815 11.111]);
saveas(gcf,'Eta.fig')
saveas(gcf,'Eta.pdf')